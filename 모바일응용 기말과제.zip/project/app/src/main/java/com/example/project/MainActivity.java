package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;

import com.example.project.data.AlarmContract;
import com.example.project.data.AlarmDBHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.FileInputStream;
import java.io.IOException;
import android.app.LoaderManager;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{

    FloatingActionButton fab1, fab2;
    CalendarView cal;
    TextView memoText;
    String fileName;
    Button btnSave,btnSelect;
    EditText edtName,edtCycle,edtEx;
    TextView viewResult;

    DBHelper dbHelper;
    ListView alarmList;
    AlarmDBHelper alarmDBHelper = new AlarmDBHelper(this);
    AlarmCursorAdapter mCursorAdapter;
    ProgressDialog prgDialog;

    private static final int VEHICLE_LOADER = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabHost tabHost = (TabHost) findViewById(R.id.tabhost);
        tabHost.setup();


        TabHost.TabSpec tabSpecCalendar = tabHost.newTabSpec("CALENDAR").setIndicator("달력");
        tabSpecCalendar.setContent(R.id.content1);
        tabHost.addTab(tabSpecCalendar);

        TabHost.TabSpec tabSpecDiction = tabHost.newTabSpec("DICTION").setIndicator("사전");
        tabSpecDiction.setContent(R.id.content2);
        tabHost.addTab(tabSpecDiction);

        TabHost.TabSpec tabSpecArlam = tabHost.newTabSpec("ARLAM").setIndicator("알람");
        tabSpecArlam.setContent(R.id.content3);
        tabHost.addTab(tabSpecArlam);

        tabHost.setCurrentTab(0);

        fab2 = (FloatingActionButton) findViewById(R.id.fab2);
        fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        cal = (CalendarView) findViewById(R.id.calendar);
        memoText = (TextView) findViewById(R.id.memotext);
        btnSave=(Button)findViewById(R.id.btnSave);
        btnSelect=(Button)findViewById(R.id.btnSelect);
        edtName=(EditText)findViewById(R.id.edtName);
        edtCycle=(EditText)findViewById(R.id.edtCycle);
        edtEx=(EditText)findViewById(R.id.edtEx);
        viewResult=(TextView)findViewById(R.id.viewResult);
        alarmList = (ListView) findViewById(R.id.alarmlist);
        View emptyView = findViewById(R.id.empty_view);
        alarmList.setEmptyView(emptyView);


        mCursorAdapter = new AlarmCursorAdapter(this, null);
        alarmList.setAdapter(mCursorAdapter);

        dbHelper=new DBHelper(MainActivity.this,1);

        alarmList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                Intent intent = new Intent(MainActivity.this, alarmAdd.class);

                Uri currentVehicleUri = ContentUris.withAppendedId(AlarmContract.AlarmReminderEntry.CONTENT_URI, id);

                intent.setData(currentVehicleUri);

                startActivity(intent);

            }
        });

        fab1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), diaryAdd.class);
                startActivity(intent);
            }
        });

        fab2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), alarmAdd.class);
                startActivity(intent);
            }
        });

        getLoaderManager().initLoader(VEHICLE_LOADER, null, this);

        cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int monthOfYear, int dayOfMonth) {
                fileName = Integer.toString(year) + "_" + Integer.toString(monthOfYear + 1) + "_" + Integer.toString(dayOfMonth) + ".txt";
                String str = readDiary(fileName);
                memoText.setText(str);
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHelper.insert(edtName.getText().toString(),edtCycle.getText().toString(),edtEx.getText().toString());
            }
        });

        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewResult.setText(dbHelper.getResult());
            }
        });

    }

    String readDiary (String fName){
        String diaryStr = null;
        FileInputStream inFs;
        try {
            inFs = openFileInput(fName);
            byte[] txt = new byte[500];
            inFs.read(txt);
            inFs.close();
            diaryStr = (new String(txt)).trim();
        } catch (IOException e) {

        }
        return diaryStr;
    }
    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        String[] projection = {
                AlarmContract.AlarmReminderEntry._ID,
                AlarmContract.AlarmReminderEntry.KEY_TITLE,
                AlarmContract.AlarmReminderEntry.KEY_DATE,
                AlarmContract.AlarmReminderEntry.KEY_TIME,
                AlarmContract.AlarmReminderEntry.KEY_REPEAT,
                AlarmContract.AlarmReminderEntry.KEY_REPEAT_NO,
                AlarmContract.AlarmReminderEntry.KEY_REPEAT_TYPE,
                AlarmContract.AlarmReminderEntry.KEY_ACTIVE

        };

        return new CursorLoader(this,
                AlarmContract.AlarmReminderEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        mCursorAdapter.swapCursor(cursor);

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mCursorAdapter.swapCursor(null);

    }

}